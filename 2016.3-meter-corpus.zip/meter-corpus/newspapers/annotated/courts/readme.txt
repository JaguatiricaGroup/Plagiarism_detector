Each directory contains a single day's articles that appeared in newspapers. PA 

provided copy on the previous day on the catchline in the sub-directory.
