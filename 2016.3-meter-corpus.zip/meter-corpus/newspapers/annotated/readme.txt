This directory contains 2 sub-directories:

1) courts - included are 770 newspaper articles relating to law courts.  These cover 24 separate days.


2) showbiz - included are 176 newspaper articles relating to showbusiness.  These cover 13 separate days.
