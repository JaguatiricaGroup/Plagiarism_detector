This directory -bbcstreet - combines pa copy from the sperate catchlines bbc

and street.



Mirror story (41) - combines copy from these two catchlines to produce a single article.



Express story (51) does the same.  It differs in that it starts by referring to the BBC and ends by referencing Coronation Street.

The Mirror does it the other way round.
