Sun story (77) combines copy supplied in two separate PA catchllines -

spice and spicefestival.



Star contains two separate stories (79 and 80) - that relate to the two separate

catchlines, though both have spice as a common factor.

